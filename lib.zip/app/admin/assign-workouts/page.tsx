import AssignWorkoutsClient from './AssignWorkoutsClient'

export default function AssignWorkoutsPage() {
  return <AssignWorkoutsClient />
}
